'use strict';

var gulp = require('gulp'),
	sass = require('gulp-sass'),
	connect = require('gulp-connect');

gulp.task('default', ['watch', 'connect', 'sass']);

gulp.task('sass', function () {
  return gulp.src('sass/**/*.scss')
  	.pipe(sass().on('error', sass.logError))
  	// .pipe(sass({outputStyle: 'compressed'}).on('error', sass.logError))
    .pipe(gulp.dest('./css/'));
});

gulp.task('connect', function() {
  connect.server();
});

gulp.task('watch', function() {
  gulp.watch('sass/**/*.scss',['sass']);
});

gulp.task('sass:watch', function () {
  gulp.watch('sass/**/*.scss', ['sass']);
});